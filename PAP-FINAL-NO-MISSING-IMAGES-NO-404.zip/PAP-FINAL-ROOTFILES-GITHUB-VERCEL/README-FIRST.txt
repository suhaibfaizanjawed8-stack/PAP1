UPLOAD EVERY FILE IN THIS FOLDER TO GITHUB ROOT.
There are intentionally NO source folders to select. This package is designed for GitHub's web upload file picker.
Do not rename or omit any file.
