import { copyFile, mkdir, readdir, rm } from 'node:fs/promises';
import { extname, resolve } from 'node:path';

const root = process.cwd();
const dist = resolve(root, 'dist');

const routes = new Map([
  ['index.html', 'index.html'],
  ['about.html', 'about/index.html'],
  ['blog.html', 'blog/index.html'],
  ['capabilities.html', 'capabilities/index.html'],
  ['case-studies.html', 'case-studies/index.html'],
  ['contact.html', 'contact/index.html'],
  ['industries.html', 'industries/index.html'],
  ['innovation.html', 'innovation/index.html'],
  ['privacy.html', 'privacy/index.html'],
  ['products.html', 'products/index.html'],
  ['quality.html', 'quality/index.html'],
  ['terms.html', 'terms/index.html'],
  ['products--3d-engravix.html', 'products/3d-engravix/index.html'],
  ['products--coldseal-blister-wallet.html', 'products/coldseal-blister-wallet/index.html'],
  ['products--honeycomb-separators.html', 'products/honeycomb-separators/index.html'],
  ['products--leaf-inserts.html', 'products/leaf-inserts/index.html'],
  ['products--pill-folders.html', 'products/pill-folders/index.html'],
  ['products--printed-cartons.html', 'products/printed-cartons/index.html'],
  ['products--printed-labels.html', 'products/printed-labels/index.html'],
  ['products--tamper-evident.html', 'products/tamper-evident/index.html'],
  ['blog--anti-counterfeiting-innovations.html', 'blog/anti-counterfeiting-innovations/index.html'],
  ['blog--eliminating-transit-breakage-glass-ampoules.html', 'blog/eliminating-transit-breakage-glass-ampoules/index.html'],
  ['blog--iso-9001-cgmp-compliance.html', 'blog/iso-9001-cgmp-compliance/index.html'],
  ['blog--optimizing-prescribing-leaflets-pil.html', 'blog/optimizing-prescribing-leaflets-pil/index.html'],
  ['blog--small-diameter-vial-ampoule-labeling.html', 'blog/small-diameter-vial-ampoule-labeling/index.html'],
  ['blog--sustainable-coldseal-blister-wallets.html', 'blog/sustainable-coldseal-blister-wallets/index.html']
]);

const imageExts = new Set(['.png', '.jpg', '.jpeg', '.webp', '.svg', '.gif', '.avif']);
const rootStatic = new Set(['design.css', 'brand-colors.css', 'interactions.js', 'image-fallbacks.js']);

await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });

for (const [source, dest] of routes) {
  const out = resolve(dist, dest);
  await mkdir(resolve(out, '..'), { recursive: true });
  await copyFile(resolve(root, source), out);
}

for (const name of await readdir(root)) {
  const ext = extname(name).toLowerCase();
  if (imageExts.has(ext)) {
    const out = resolve(dist, 'assets/images', name);
    await mkdir(resolve(out, '..'), { recursive: true });
    await copyFile(resolve(root, name), out);
  } else if (rootStatic.has(name)) {
    await copyFile(resolve(root, name), resolve(dist, name));
  }
}

await mkdir(resolve(dist, 'assets/fonts/inter'), { recursive: true });
await mkdir(resolve(dist, 'assets/fonts'), { recursive: true });
await copyFile(resolve(root, 'inter-variable.woff2'), resolve(dist, 'assets/fonts/inter/inter-variable.woff2'));
await copyFile(resolve(root, 'remixicon.css'), resolve(dist, 'assets/fonts/remixicon.css'));
await copyFile(resolve(root, 'remixicon.woff2'), resolve(dist, 'assets/fonts/remixicon.woff2'));

console.log(`Build complete: ${routes.size} HTML pages plus images/fonts/CSS/JS written to dist/.`);
