import { readFile, readdir, access, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const root = process.cwd();
const dist = resolve(root, 'dist');
const requiredRoutes = [
  '/', '/about/', '/products/', '/capabilities/', '/innovation/', '/quality/', '/industries/',
  '/contact/', '/case-studies/', '/blog/', '/privacy/', '/terms/',
  '/products/3d-engravix/', '/products/coldseal-blister-wallet/', '/products/honeycomb-separators/',
  '/products/leaf-inserts/', '/products/pill-folders/', '/products/printed-cartons/',
  '/products/printed-labels/', '/products/tamper-evident/',
  '/blog/anti-counterfeiting-innovations/', '/blog/eliminating-transit-breakage-glass-ampoules/',
  '/blog/iso-9001-cgmp-compliance/', '/blog/optimizing-prescribing-leaflets-pil/',
  '/blog/small-diameter-vial-ampoule-labeling/', '/blog/sustainable-coldseal-blister-wallets/'
];

function routeFile(route) {
  return route === '/' ? resolve(dist, 'index.html') : resolve(dist, route.slice(1), 'index.html');
}

for (const route of requiredRoutes) await access(routeFile(route));

const files = [];
async function walk(dir) {
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = resolve(dir, e.name);
    if (e.isDirectory()) await walk(p);
    else files.push(p);
  }
}
await walk(dist);

const html = files.filter(f => f.endsWith('.html'));
const missing = [];
const refs = [];
const attrRe = /<(img|script|link|a|source)\b[^>]*?\b(src|href|srcset)=["']([^"']+)["'][^>]*>/gi;
const cssUrlRe = /url\(["']?([^"')]+)["']?\)/gi;

for (const file of html) {
  const text = await readFile(file, 'utf8');
  let m;
  while ((m = attrRe.exec(text))) {
    const isLink = m[1].toLowerCase() === 'a';
    const raw = m[3];
    if (/^(https?:|mailto:|tel:|data:|javascript:|#)/i.test(raw)) continue;
    const clean = decodeURIComponent(raw.split('#')[0].split('?')[0].split(',')[0].trim().split(/\s+/)[0]);
    let p = clean.startsWith('/') ? resolve(dist, clean.slice(1)) : resolve(dirname(file), clean);
    if (isLink && clean.endsWith('/')) p = resolve(p, 'index.html');
    refs.push([file, raw, p]);
    if (!existsSync(p)) missing.push(`${file.replace(dist,'dist')}: ${raw}`);
  }
}
for (const file of files.filter(f => f.endsWith('.css'))) {
  const text = await readFile(file, 'utf8');
  let m;
  while ((m = cssUrlRe.exec(text))) {
    const raw = m[1];
    if (/^(https?:|data:)/i.test(raw)) continue;
    const clean = decodeURIComponent(raw.split('#')[0].split('?')[0]);
    const p = clean.startsWith('/') ? resolve(dist, clean.slice(1)) : resolve(dirname(file), clean);
    refs.push([file, raw, p]);
    if (!existsSync(p)) missing.push(`${file.replace(dist,'dist')}: ${raw}`);
  }
}
if (missing.length) throw new Error(`Missing references (${missing.length}):\n${missing.join('\n')}`);
console.log(`PASS: ${requiredRoutes.length} routes, ${html.length} HTML files, ${refs.length} local references, 0 missing.`);
