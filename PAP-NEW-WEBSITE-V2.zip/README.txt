PRINCE ART PACKAGES — NEW WEBSITE V2

This is a new single-page website inspired by the previous design.
All images, CSS and JavaScript are embedded in index.html, so there are no external image-path dependencies.

GitHub/Vercel:
- Upload the CONTENTS of this folder to the repository root.
- Framework Preset: Other
- Root Directory: leave empty
- Build Command: npm run build
- Output Directory: dist
- Install Command: leave empty

The navigation uses #section anchors. Vercel also rewrites unknown paths to index.html to avoid 404s.
