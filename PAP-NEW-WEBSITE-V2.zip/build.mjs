import { mkdir, copyFile, rm } from 'node:fs/promises';
await rm('dist', { recursive:true, force:true });
await mkdir('dist', { recursive:true });
await copyFile('index.html','dist/index.html');
console.log('Built dist/index.html');
